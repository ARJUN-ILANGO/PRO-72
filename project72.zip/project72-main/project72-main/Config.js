import firebase from 'firebase';
require('@firebase/firestore')

// Your web app's Firebase configuration
var firebaseConfig = {
    apiKey: "AIzaSyBp76hXvdrkLwRs8u5y6nsm4Z3Sz7D0w0A",
    authDomain: "newsletter-878a4.firebaseapp.com",
    databaseURL: "https://newsletter-878a4-default-rtdb.firebaseio.com",
    projectId: "newsletter-878a4",
    storageBucket: "newsletter-878a4.appspot.com",
    messagingSenderId: "670802601128",
    appId: "1:670802601128:web:bdf280e669cc9283d88e9d"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);